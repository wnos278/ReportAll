# Import modules
from Crypto.Cipher import AES
from Crypto import Random
from Crypto.Util import Counter


# Pad for short keys
pad = '# constant pad for short keys ##'

# Generate a random initialization vector, to be used by both encryptor and decryptor
# This may be sent in clear in a real communication

random_generator = Random.new()
IV = random_generator.read(8)

# Encryption steps

# Ask user for input and pad or truncate to a 32 bytes (256 bits) key
prompt = 'Input your key. It will padded or truncated at 32 bytes (256 bits).\n-: '
user_keye = input(prompt)
keye = (user_keye + pad)[:32]

plaintext = input('Enter message to cipher: ')
def encrypt(keye, plaintext):
    ctr_e = Counter.new(64, prefix=IV)
    encryptor = AES.new(keye.encode('utf-8'), AES.MODE_CTR, counter=ctr_e)
    ciphertext = encryptor.encrypt(plaintext.encode('utf-8'))
    return ciphertext


# Decryption steps

# Ask user for key: it must be equal to that used for encryption
prompt = 'Input your key. It will padded or truncated at 32 bytes (256 bits).\n-: '
user_keyd = input(prompt)
keyd = (user_keyd + pad)[:32]

# Create counter for decryptor: it is equal to the encryptor, but restarts from the beginning
def decrypt(keyd, ciphertext):
    ctr_d = Counter.new(64, prefix=IV)
    decryptor = AES.new(keyd.encode('utf-8'), AES.MODE_CTR, counter=ctr_d)
    decoded_text = decryptor.decrypt(ciphertext.encode('utf-8'))
    return decoded_text