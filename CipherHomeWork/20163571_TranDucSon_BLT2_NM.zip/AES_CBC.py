from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto import Random

key_size = 16 #AES128
iterations = 10000
key = b'password'
secret = b'ciphertext'

length = 16 - (len(secret) % 16)
secret += chr(length) * length

salt = Random.new().read(key_size) #salt the hash
iv = Random.new().read(AES.block_size)
derived_key = PBKDF2(key, salt, key_size, iterations)
cipher = AES.new(derived_key, AES.MODE_CBC, iv)

encodedtext = iv + cipher.encrypt(secret)
decodedtext = str(cipher.decrypt(encodedtext))[16:-ord(decodedtext[-1])] #remove iv and padding